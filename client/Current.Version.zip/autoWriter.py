index = 1
for x in range (10, 14):
  for y in range (1, 18):
    print "  <string name=\"lin1\" index=\"" + str(index) + "\">" + str(x) + "00" + str(-y) + "</string>"
    index = index + 1
m = raw_input
